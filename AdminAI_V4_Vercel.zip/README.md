# AdminAI V4 — Vercel
Sube esta estructura al repositorio de GitHub.

Variables de entorno en Vercel:
- OPENAI_API_KEY = tu clave privada
- OPENAI_MODEL = modelo habilitado para tu cuenta

No subas la API key a GitHub.
