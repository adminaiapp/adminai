# AdminAI V3 — primera integración de IA real

Esta versión agrega un backend seguro que recibe los datos del formulario y llama a la OpenAI Responses API. La clave no se coloca en el HTML ni se envía al navegador.

## Requisitos
- Node.js 20+ recomendado.
- Una API key de OpenAI con facturación/configuración para API.

## Ejecutar
1. Abre una terminal dentro de `AdminAI_V3`.
2. Define `OPENAI_API_KEY` como variable de entorno.
3. Opcionalmente define `OPENAI_MODEL` (por defecto: `gpt-5.6`).
4. Ejecuta: `npm start`
5. Abre: http://localhost:3000

En Windows PowerShell:
$env:OPENAI_API_KEY="TU_CLAVE"
npm start

En macOS/Linux:
export OPENAI_API_KEY="TU_CLAVE"
npm start

## Seguridad
No pongas la clave dentro de `public/index.html`, no la subas a GitHub y no la compartas en el chat. En producción usaremos variables de entorno/secret manager.

## Qué hace
- Envía la solicitud al endpoint `/api/generate-quote`.
- El servidor llama a `/v1/responses`.
- La IA devuelve un JSON con los campos de la cotización.
- El navegador muestra el resultado.
