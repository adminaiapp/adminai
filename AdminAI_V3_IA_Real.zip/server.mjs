import http from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join } from "node:path";
import { URL } from "node:url";

const PORT = process.env.PORT || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-5.6";

const mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8"
};

function send(res, status, body, type="application/json; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": type,
    "Cache-Control": "no-store"
  });
  res.end(typeof body === "string" ? body : JSON.stringify(body));
}

async function body(req) {
  let data = "";
  for await (const chunk of req) data += chunk;
  return JSON.parse(data || "{}");
}

function cleanNumber(value, fallback=0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

async function generateQuote(input) {
  if (!OPENAI_API_KEY) {
    throw new Error("Falta OPENAI_API_KEY. Configúrala como variable de entorno antes de iniciar el servidor.");
  }

  const payload = {
    model: OPENAI_MODEL,
    input: [
      {
        role: "system",
        content: `Eres AdminAI, un asistente administrativo para pequeños negocios.
Convierte la información del usuario en una cotización profesional.
No inventes datos del negocio, del cliente, precios, impuestos ni condiciones que no hayan sido proporcionados.
Devuelve SOLO JSON válido con estas claves:
client, email, description, quantity, unit_price, discount_percent, tax_percent, subtotal, discount_amount, tax_amount, total, validity_days, notes.
Los importes deben ser números. Si falta un dato opcional, usa "" para texto o 0 para números.
Calcula correctamente subtotal, descuento, impuesto y total.`
      },
      {
        role: "user",
        content: JSON.stringify(input)
      }
    ]
  };

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify(payload)
  });

  const raw = await response.text();
  if (!response.ok) {
    throw new Error(`OpenAI API ${response.status}: ${raw.slice(0, 500)}`);
  }

  const data = JSON.parse(raw);
  const text = data.output_text || "";
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("La IA respondió en un formato inesperado. Intenta nuevamente.");
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "POST" && url.pathname === "/api/generate-quote") {
      const input = await body(req);
      const quote = await generateQuote({
        client: String(input.client || ""),
        email: String(input.email || ""),
        description: String(input.description || ""),
        quantity: cleanNumber(input.quantity, 1),
        unit_price: cleanNumber(input.unit_price, 0),
        discount_percent: cleanNumber(input.discount_percent, 0),
        tax_percent: cleanNumber(input.tax_percent, 0),
        currency: String(input.currency || "USD")
      });
      return send(res, 200, { ok: true, quote });
    }

    if (req.method === "GET") {
      let pathname = url.pathname === "/" ? "/index.html" : url.pathname;
      const file = join(public, pathname);
      const data = await readFile(file);
      return send(res, 200, data, mime[extname(file)] || "application/octet-stream");
    }

    return send(res, 404, { ok: false, error: "Ruta no encontrada." });
  } catch (err) {
    console.error(err);
    return send(res, 500, { ok: false, error: err.message || "Error interno." });
  }
});

server.listen(PORT, () => {
  console.log(`AdminAI V3 ejecutándose en http://localhost:${PORT}`);
  console.log(`Modelo configurado: ${OPENAI_MODEL}`);
});
